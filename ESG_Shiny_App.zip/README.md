
# ESG-Adjusted Financial Health Explorer

This Shiny app helps visualize the impact of ESG (Environmental, Social, Governance) scores on traditional financial risk metrics. Built for use in financial consulting, especially for EY FAAS teams focused on ESG-integrated risk analysis.

## 📊 What It Does

- Simulates financial and ESG data for 100 firms
- Computes Altman Z-Score (financial health index)
- Applies Principal Component Analysis (PCA) to ESG metrics
- Computes ESG-adjusted Z-Score
- Interactive visualization and company lookup

## 🚀 How to Run

### Option 1: RStudio Cloud

1. Go to [https://rstudio.cloud](https://rstudio.cloud)
2. Create a new project
3. Upload the `app.R` file
4. Click **Run App**

### Option 2: Locally in RStudio

1. Unzip the project folder
2. Open `app.R` in RStudio
3. Click **Run App**

## 📁 Files Included

- `app.R` – Main Shiny app script
- `README.md` – This file

## 🧠 Use Case

This tool is especially valuable for clients exploring ESG assurance, portfolio screening, or integrated reporting. Firms with strong financials but weak ESG signals are flagged, giving EY consultants deeper insight into emerging risk.

---

Made for Financial Accounting Advisory Services (FAAS) ESG analysis at EY.
